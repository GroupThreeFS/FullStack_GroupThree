CREATE TABLE Consoles(
   PlatformID SERIAL PRIMARY KEY, 
   Platform VARCHAR(12) NOT NULL,
   ReleaseDate DATE NOT NULL
);

CREATE TABLE Developers(
   DeveloperID SERIAL PRIMARY KEY, 
   DeveloperName VARCHAR(24) NOT NULL,
   Country VARCHAR(32) NOT NULL,
   TeamSize INTEGER NOT NULL
);


CREATE TABLE Games(
   GameID SERIAL PRIMARY KEY,
   GameName VARCHAR(21) NOT NULL,
   Players INTEGER NOT NULL,
   ReleaseYear INTEGER NOT NULL,
   Genre VARCHAR(10) NOT NULL,
   DeveloperID INTEGER NOT NULL,
   PlatformID INTEGER NOT NULL, -- Reference to PlatformID in Consoles
   GameRating NUMERIC(3,1) NOT NULL,
   FOREIGN KEY (DeveloperID) REFERENCES Developers(DeveloperID),
   FOREIGN KEY (PlatformID) REFERENCES Consoles(PlatformID) -- Reference to PlatformID in Consoles
);

