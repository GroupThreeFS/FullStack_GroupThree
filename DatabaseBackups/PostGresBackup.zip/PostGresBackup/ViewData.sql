SELECT * FROM Consoles;
SELECT * FROM Developers;
SELECT * FROM Users;
SELECT * FROM Games;

SELECT Platform, ReleaseDate FROM Consoles;
SELECT DeveloperName, Country FROM Developers;
SELECT Username, Email FROM Users;
SELECT GameName, Genre, GameRating FROM Games;



/*Inner Join Between Games and Consoles*/
SELECT g.GameName, g.Genre, c.Platform
FROM Games g
INNER JOIN Consoles c ON g.PlatformID = c.PlatformID;

/*Inner Join Between Games, Consoles, and Developers*/
SELECT g.GameName, c.Platform, d.DeveloperName
FROM Games g
INNER JOIN Consoles c ON g.PlatformID = c.PlatformID
INNER JOIN Developers d ON g.DeveloperID = d.DeveloperID;

/*Left Join Between Games and Developers*/
SELECT g.GameName, g.Genre, d.DeveloperName
FROM Games g
LEFT JOIN Developers d ON g.DeveloperID = d.DeveloperID;

/*Right Join Between Games and Consoles*/
SELECT c.Platform, g.GameName
FROM Games g
RIGHT JOIN Consoles c ON g.PlatformID = c.PlatformID;

/*Full Outer Join Between Games and Developers*/
SELECT g.GameName, d.DeveloperName
FROM Games g
FULL OUTER JOIN Developers d ON g.DeveloperID = d.DeveloperID;

